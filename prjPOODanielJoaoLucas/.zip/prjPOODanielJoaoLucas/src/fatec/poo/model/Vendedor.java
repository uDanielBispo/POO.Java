package fatec.poo.model;

import java.util.ArrayList;

public class Vendedor extends Pessoa{
	private double salarioBase;
	private double taxaComissão;
	private ArrayList<Pedido> pedidos;
	
	public Vendedor(String cpf, String nome, double salarioBase) {
            super(cpf, nome);
            this.salarioBase = salarioBase;
            pedidos = new ArrayList<Pedido>();
	}

	public void addPedido(Pedido pedido) {
		pedidos.add(pedido);
		pedido.setVendedor(this);
	}
	
	public double getSalarioBase() {
            return salarioBase;
	}

	public void setSalarioBase(double salarioBase) {
            this.salarioBase = salarioBase;
	}

	public double getTaxaComissao() {
            return taxaComissão;
	}

	public void setTaxaComissão(double taxaComissão) {                
            this.taxaComissão = taxaComissão/100;
	}

	
}

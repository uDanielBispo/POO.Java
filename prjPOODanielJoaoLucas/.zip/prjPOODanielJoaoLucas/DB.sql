create table tbPessoa(
cpf varchar2(14),
nome varchar2(40),
endereco varchar2(40),
cidade varchar2(20),
uf varchar2(2),
cep varchar2(8),
ddd varchar2(2),
telefone varchar2(9),
constraint pk_cpf primary key (cpf)
);

create table tbCliente(
idCliente int,
cpfCliente varchar2(14),
limiteCred number,
limiteDisp number,
constraint pk_idCliente primary key (idCliente),
constraint fk_cpfCliente foreign key (cpfCliente) references tbPessoa(cpf)
);
create sequence sq_idCliente 
start with 1
increment by 1;

CREATE TABLE tbVendedor(
cpfVendedor VARCHAR2(14) PRIMARY KEY,
salarioBase NUMBER,
taxaComissao NUMBER,
CONSTRAINT fk_vendedor foreign key (cpfVendedor) references tbPessoa(cpf)
);

CREATE TABLE tbProduto(
codigo number,
descricao varchar2(100),
qtdeDisp number,
preco number,
estoqueMin number,
CONSTRAINT pk_produto PRIMARY KEY (codigo)
);

select * from tbPessoa;
select * from tbCliente;
select * from tbVendedor;
select * from tbProduto;

insert into tbPessoa(cpf,nome,endereco,cidade,uf,cep,ddd,telefone) values('889.545.418-52','Lucas Ferreira','Serra bonita','Sorocaba','SP','18050600','15','997651019');
insert into tbPessoa(cpf,nome,endereco,cidade,uf,cep,ddd,telefone) values('789.545.418-52','Lucas Ferreira','Serra bonita','Sorocaba','SP','18050600','15','997651019');
insert into tbPessoa(cpf,nome,endereco,cidade,uf,cep,ddd,telefone) values('689.545.418-52','Lucas Ferreira','Serra bonita','Sorocaba','SP','18050600','15','997651019');
insert into tbPessoa(cpf,nome,endereco,cidade,uf,cep,ddd,telefone) values('589.545.418-52','Lucas Ferreira','Serra bonita','Sorocaba','SP','18050600','15','997651019');
insert into tbPessoa(cpf,nome,endereco,cidade,uf,cep,ddd,telefone) values('389.545.418-52','Lucas Ferreira','Serra bonita','Sorocaba','SP','18050600','15','997651019');

insert into tbCliente (idCliente, cpfCliente,limiteCred,limiteDisp) values(sq_idCliente.nextval,'889.545.418-52',1000,1000);
insert into tbCliente (idCliente, cpfCliente,limiteCred,limiteDisp) values(sq_idCliente.nextval,'789.545.418-52',1000,1000);
insert into tbCliente (idCliente, cpfCliente,limiteCred,limiteDisp) values(sq_idCliente.nextval,'689.545.418-52',1000,1000);
insert into tbCliente (idCliente, cpfCliente,limiteCred,limiteDisp) values(sq_idCliente.nextval,'589.545.418-52',1000,1000);
insert into tbCliente (idCliente, cpfCliente,limiteCred,limiteDisp) values(sq_idCliente.nextval,'489.545.418-52',1000,1000);

INSERT INTO tbVendedor VALUES('389.545.418-52', 10, 10);

SELECT * FROM tbPessoa 
INNER JOIN tbVendedor
ON tbPessoa.cpf = tbVendedor.cpfVendedor
WHERE cpfVendedor = '389.545.418-52';
